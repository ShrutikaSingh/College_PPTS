import { Time } from '@angular/common';

export class Regulartrip {


    origin: string;
   
    destination: string;

    depTime: string;
    endTime: String;
    depDate: string;
    endDate: string;
    amount: number;

    meetPoint1: string;

    driverId: string;

    smoking: boolean;

    pets: boolean;

}
