import { Time } from '@angular/common';

export class Frequenttrip {
        origin:string;
        destination:string;
	    startDate:string;
        finishDate:string;
        amount:number;
	    driverId:string;
        depTime:Time;
}