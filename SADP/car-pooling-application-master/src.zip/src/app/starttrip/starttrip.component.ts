import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-starttrip',
  templateUrl: './starttrip.component.html',
  styleUrls: ['./starttrip.component.css']
})
export class StarttripComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
