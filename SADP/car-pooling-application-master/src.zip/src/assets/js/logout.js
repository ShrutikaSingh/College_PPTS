function resultlogout()
{
//Rating : Count
//Review : Comment(id)
alert("Are you sure you want to logout?");
}